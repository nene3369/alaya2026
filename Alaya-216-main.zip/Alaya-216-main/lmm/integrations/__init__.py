"""Framework integrations — LangChain, LlamaIndex."""

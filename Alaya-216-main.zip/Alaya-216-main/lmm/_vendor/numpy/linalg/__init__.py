"""numpy.linalg sub-package shim -- re-exports from parent."""
from numpy import linalg as _la

norm = _la.norm
